def AddTwo(num):
    return num+2

def SayHello(name):
    return "Hello"+name+" , this is package"