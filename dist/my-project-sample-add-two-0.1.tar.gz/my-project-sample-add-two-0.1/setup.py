from setuptools import setup, find_packages

setup(
    name='my-project-sample-add-two',
    version='0.1',
    description='A simple package ',
    author='abi',
    author_email='abithathangavel03@gmail.com',
    packages=find_packages(),
)